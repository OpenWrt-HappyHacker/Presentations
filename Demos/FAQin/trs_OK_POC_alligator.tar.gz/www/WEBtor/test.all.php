<?php

function
s2p ($s)
{
    $p = '';
    for ($i = 0; $i < strlen ($s); $i++)
        $p .= $s{$i} . '/';
    return $p;
}

$file= '/www/storage-jirafeau@usb/test.file.junk';

$md5 = md5_file ($file);
$size = filesize($file);
$np = s2p ($md5);

echo 'file: ' . $file . ' md5: ' . $md5 . ' size: ' . $size . ' np: ' . $np ;
//echo 'timestamp: ' . date('U');

//echo 'Random string: ' . substr(str_shuffle((MD5(microtime())), 0, 11));
//echo 'microtime() :' . microtime() ;

?>