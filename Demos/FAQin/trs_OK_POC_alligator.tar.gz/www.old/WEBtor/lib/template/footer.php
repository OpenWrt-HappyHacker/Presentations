
<div id="copyright">
    <p>
        <br />
        <a href="https://www.gnu.org/licenses/agpl.html"><abbr title="Affero General Public License">AGPL</abbr>v3</a> |
        <a href="https://gitlab.com/mojo42/Jirafeau"><?php echo t('Jirafeau Project') ?></a> |
        <a href="<?php echo rtrim($cfg['web_root'], '/') . '/tos.php'; ?>"><?php echo t('Term Of Service') ?></a>
    </p>
</div>
</div>
<div id="jyraphe">
</div>
</body>
</html>
